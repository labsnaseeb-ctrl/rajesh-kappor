Rajesh Kapoor Portfolio — GitHub Pages Upload

Files:
- index.html: Keep this filename for GitHub Pages to open the portfolio automatically at the website root.
- Rajesh_Kapoor.html: Same portfolio with your preferred filename; after upload it can be opened at https://YOUR-USERNAME.github.io/Rajesh_Kapoor.html

Publish both files in the repository's root folder. Then enable GitHub Pages in Settings > Pages, deploying from branch main and folder /(root).
Replace YOUR-USERNAME with your GitHub username.
